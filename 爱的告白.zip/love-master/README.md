# love

演示地址：https://gonghongchen.github.io/love/index.html
<br/>
点击本页面右上角绿色按钮【Clone or download】，然后点击【Download ZIP】即可。
可提供的更改：
1.可以用编辑器（比如记事本）直接打开【index.html】文件，然后根据代码里面我写的中文提示修改对应的内容；
2.可以直接把【music】文件夹中的音乐替换为你喜欢的歌曲文件。

注：几年前也不知道下载的哪位大神的代码，并非原创，现在只不过是整理下放到这儿把好的东西分享给大家而已。
